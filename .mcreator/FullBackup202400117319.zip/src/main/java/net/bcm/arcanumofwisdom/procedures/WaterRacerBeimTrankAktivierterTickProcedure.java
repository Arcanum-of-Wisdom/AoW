package net.bcm.arcanumofwisdom.procedures;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;
import net.minecraft.core.BlockPos;

import net.bcm.arcanumofwisdom.init.ArcanumOfWisdomModBlocks;

public class WaterRacerBeimTrankAktivierterTickProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		if ((world.getBlockState(BlockPos.containing(x, y - 1, z))).getBlock() == Blocks.WATER && (world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == Blocks.AIR) {
			if (entity.isShiftKeyDown()) {
				if ((world.getBlockState(BlockPos.containing(x, y - 1, z))).getBlock() == ArcanumOfWisdomModBlocks.FAKE_WATER_BLOCK.get()) {
					world.setBlock(BlockPos.containing(x, y - 1, z), Blocks.WATER.defaultBlockState(), 3);
				}
				if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == ArcanumOfWisdomModBlocks.FAKE_WATER_BLOCK.get()) {
					world.setBlock(BlockPos.containing(x, y, z), Blocks.WATER.defaultBlockState(), 3);
				}
			} else {
				world.setBlock(BlockPos.containing(x, y - 1, z), ArcanumOfWisdomModBlocks.FAKE_WATER_BLOCK.get().defaultBlockState(), 3);
			}
		}
	}
}
